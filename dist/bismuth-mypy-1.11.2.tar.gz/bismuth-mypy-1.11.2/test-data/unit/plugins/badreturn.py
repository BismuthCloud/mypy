def plugin(version: str) -> None:
    pass
